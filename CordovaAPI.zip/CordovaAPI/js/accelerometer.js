document.addEventListener("deviceready", accelerometerAPI, false);

function accelerometerAPI() {

	$(function(){

		function onSuccess(acceleration) {
		    $('#X').html(	  acceleration.x 		 );
		    $('#Y').html(	  acceleration.y 		 );
		    $('#Z').html(     acceleration.z 		 );
		    $('#stamp').html( new Date(acceleration.timestamp) );
		}

		function onError() {
		    $('#X, #Y, #Z, #stamp').html('Error!!');
		};

		$('#GetValues').on('touchend',function(){

			navigator.accelerometer.getCurrentAcceleration(onSuccess, onError);

		});

        //id for intervall 
		var watchID = false;

		$('#WatchValues').on('touchend',function(){

			if(watchID === false) { //important otherwise a lot of intervalls are generated and only the last one can get closed
                watchID = navigator.accelerometer.watchAcceleration(onSuccess, onError, { frequency: 100  } );
            }

		});

		$('#StopWatching, #closeAccelerometer').on('touchend',function(){

			if (watchID !== false) {
				navigator.accelerometer.clearWatch(watchID);
				watchID = false;
			}

			$('#X, #Y, #Z, #stamp').html('');

		});

	});

}