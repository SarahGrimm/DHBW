document.addEventListener("deviceready", inAppBrowserAPI, false);

function inAppBrowserAPI() {

	$(function(){

		$('#openNormal').on('touchend',function(){

			window.open('http://www.google.com/', '_system');

		});

		$('#openWin').on('touchend',function(){

			window.open('http://www.google.com/', '_blank');

		});

		$('#openWithOptions').on('touchend',function(){

			var optionsArr = [
				// For all OS's Android: no->disables top bar
				'location=no',
				
				// For Android, iOS & Windows Phone only, yes->page loaded in background
				'hidden=yes',
				
				// Android and iOS only
				'clearcache=yes',
				'clearsessioncache=yes',
				
				// iOS only
				// Transition style options are fliphorizontal, crossdissolve or coververtical (Default)
				'transitionstyle=fliphorizontal',
				'toolbar=yes',
				'closebuttoncaption=Exit',
				// Tool bar position options are top or bottom (Default)
				'toolbarposition=top',
				'disallowoverscroll=yes',
				'enableViewportScale=yes',
				'mediaPlaybackRequiresUserAction=yes',
				'allowInlineMediaPlayback=yes',
				'keyboardDisplayRequiresUserAction=no',
                //waits until assets are loaded
				'suppressesIncrementalRendering=yes',
				// Presentation style options are pagesheet, formsheet or fullscreen (Default)
				'presentationstyle=formsheet',

				// Android only
				'zoom=no',
                //back button closes inappbrowser
				'hardwareback=no',
				
				// Windows only
				// If location is set to no there be no control presented to user to close IAB window.
				'fullscreen=yes'
			]

			var options = optionsArr.join();

			var browserOptions = window.open('http://www.google.com/', '_blank', options );

			browserOptions.show();

		});

		function BrowserCallback( event ) {
     		console.log(event, event.type, event.url);
     	}

		$('#openWithEvents').on('touchend',function(){

			var eventfulBrowser = window.open('http://www.google.com/', '_blank');

			eventfulBrowser.addEventListener('loadstart', BrowserCallback);
         	eventfulBrowser.addEventListener('loadstop',  BrowserCallback);
         	eventfulBrowser.addEventListener('loaderror', BrowserCallback);
         	eventfulBrowser.addEventListener(  'exit',	  BrowserCallback);

		});

		$('#openCloseWin').on('touchend',function(){

			var browserClose = window.open('http://www.google.com/', '_blank');

			setTimeout(function(){
				browserClose.close();
			},3000);

		});

		$('#passCSS').on('touchend',function(){

			var browserCSS = window.open('http://www.google.com/', '_blank');
            //ready loaded 
			browserCSS.addEventListener('loadstop',  function(){
				
				browserCSS.insertCSS(
					//inject link into dom, server site 
					{ file: 'styles.css' }

				);

				browserCSS.insertCSS(
					
					{ code: 'body #mobile-header { background-color:black; }' }

				);
			});

		});


		$('#passJS').on('touchend',function(){

			var browserJS = window.open('http://www.google.com/', '_blank');

			browserJS.addEventListener('loadstop',  function(){
				
				browserJS.executeScript(
					
					{ file: 'mine.js' }

				);

				browserJS.executeScript(
					
					{ code: 'alert("YUP");' }

				);

			});

		});



	});

}