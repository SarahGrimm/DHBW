document.addEventListener("deviceready", cameraAPI, false);

function cameraAPI() {

    $(function(){

    	function camSuccess(imageData){

    		console.log(imageData);

    		var img = '<img src="'+imageData+'" style=" display:block; padding:0px 15px 15px 15px; box-sizing:border-box; width:100%; margin:0 auto"/>';

    		$('#CameraOutput').html( img );

    	}

    	function camError(errorMessage){

    		alert('Error: '+ errorMessage );

    	}

		$('#CamPicture').on('touchend',function(){

			var options = {
                
                //0 - 100, % of quality, 100% -> without compression
				'quality': 85,
                //create boundryBox, ration of the image will be reserved
				'targetWidth': 1280,
				'targetHeight': 720,
                //true -> save to device storage, false -> save to app cache -> when app quites image is destroyed
				'saveToPhotoAlbum': false,
                //true-> basic image edits
				'allowEdit': false,
                
                //defines what will be returned to success callback
				'destinationType' : navigator.camera.DestinationType.FILE_URI,
				/*
					0: DATA_URL      //never use DAT_URL->cause App will crash on devices with hd cameras,  Return image as base64-encoded string -> uncomressed, binary string, causes memory issues, default
					
                    1: FILE_URI      //Return image file URI(uniform resource identifier)-> returns path of image/video
                    
					2: NATIVE_URI    //Return image native URI (assets-library:// for iOS or content:// for Android)-results are the same
				*/

				'sourceType' : navigator.camera.PictureSourceType.CAMERA,
				/*
					0: PHOTOLIBRARY // IOS: all media from every source
					1: CAMERA
					2: SAVEDPHOTOALBUM //same as Photolibrary in Android, IOS: only images and videos created by the camero of the device
				*/

                //What media can be selected?
				'MediaType':  navigator.camera.MediaType.PICTURE,
				/*
					0: PICTURE		// allow selection of still pictures only. DEFAULT. Will return format specified via DestinationType
					1: VIDEO: 		// allow selection of video only, WILL ALWAYS RETURN FILE_URI
					2: ALLMEDIA	// allow selection from all media types
			  	*/

				'encodingType': navigator.camera.EncodingType.JPEG,
				/*
					0: JPEG		// Return JPEG encoded image
					1: PNG			// Return PNG encoded image
				*/
				
			  	'Direction': navigator.camera.Direction.BACK, 
			  	/*
					0: BACK 		// Use the back-facing camera
					1: FRONT		// Use the front-facing camera
				*/

			}

			navigator.camera.getPicture( camSuccess, camError, options );

		});

    	$('#GalImage').on('touchend',function(){

			// u don't have to set all options cause they are set to default
            var options = {

				'destinationType': 1,
				// DATA_URL: 0,  FILE_URI: 1,  NATIVE_URI: 2

				'sourceType': 0,
				// PHOTOLIBRARY: 0, CAMERA: 1, SAVEDPHOTOALBUM: 2

				'mediaType':  0,
				// PICTURE: 0, VIDEO: 1, ALLMEDIA: 2

			}

			navigator.camera.getPicture( camSuccess, camError, options );

		});

		$('#GalImageEdit').on('touchend',function(){

			var options = {

				'allowEdit': true,

				'destinationType': 1,
				// DATA_URL: 0,  FILE_URI: 1,  NATIVE_URI: 2

				'sourceType': 0,
				// PHOTOLIBRARY: 0, CAMERA: 1, SAVEDPHOTOALBUM: 2

				'mediaType':  0,
				// PICTURE: 0, VIDEO: 1, ALLMEDIA: 2

			}

			navigator.camera.getPicture( camSuccess, camError, options );

		});

		// VIDEO SELECT FROM PHOTOLIBRARY

		function uriSuccess(file_URI){

    		$('#CameraOutput').html( '<p style=" margin:0; padding:0px 15px 15px 15px; ">'+ file_URI +'</p>' );

    	}
        
        
        //html video element is really limited-> third party lib when u need to show videos
		$('#GalVideo').on('touchend',function(){

			var options = {

				'destinationType' : 1,
				// DATA_URL: 0,  FILE_URI: 1,  NATIVE_URI: 2

				'sourceType' : 0,
				// PHOTOLIBRARY: 0, CAMERA: 1, SAVEDPHOTOALBUM: 2

				'mediaType':  1,
				// PICTURE: 0, VIDEO: 1, ALLMEDIA: 2

			}

			navigator.camera.getPicture( uriSuccess, camError, options );

		});

		$('#GalAll').on('touchend',function(){

			var options = {

				'destinationType' : 1,
				// DATA_URL: 0,  FILE_URI: 1,  NATIVE_URI: 2

				'sourceType' : 0,
				// PHOTOLIBRARY: 0, CAMERA: 1, SAVEDPHOTOALBUM: 2

				'mediaType':  2,
				// PICTURE: 0, VIDEO: 1, ALLMEDIA: 2

			}

			navigator.camera.getPicture( uriSuccess, camError, options );

		});

		// iPad ONLY
		$('#GalPopover').on('touchend',function(){

			var options = { 
					
				'destinationType': 1,
				// DATA_URL: 0,  FILE_URI: 1,  NATIVE_URI: 2
       				
       			'sourceType': 0,
       			// PHOTOLIBRARY: 0, CAMERA: 1, SAVEDPHOTOALBUM: 2
       				
                //x, y, width, height, arrow direction
                //ARROW_DOWN
                //ARROW_LEFT...
       			'popoverOptions': new CameraPopoverOptions(300, 180, 200, 200, Camera.PopoverArrowDirection.ARROW_UP)

       		}

			navigator.camera.getPicture(camSuccess, camError, options);

		});
		
	});

}