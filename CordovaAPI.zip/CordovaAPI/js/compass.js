document.addEventListener("deviceready", compassAPI, false);

function compassAPI() {

    $(function(){

    	function compassSuccess(heading) {
		    $('#NeedleTrue').css('-webkit-transform', 'rotate('+ heading.trueHeading + 'deg)');
		    $('#NeedleMagnetic').css('-webkit-transform', 'rotate('+ heading.magneticHeading + 'deg)');
		    //differnce between trueHeading and magneticHeading 
            $('#compassAccuracy').html( heading.headingAccuracy );
		    $('#compassStamp').html( new Date(heading.timestamp) );
		};

		function compassError(error) {
            //1: internal error-sensor damaged, 2: device doesn't have magnetosensor or cant locate it 
		    alert('CompassError: ' + error.code);
		};

		$('#GetHeading').on('touchend',function(){

			navigator.compass.getCurrentHeading(compassSuccess, compassError);

		});

		var watchCompass = false;
        
        //filter is not supported on Android but on IOS. filter: watch the sensor change in degrees and update the dom
        //change in 50 degree dom is updated
		$('#WatchHeading').on('touchend',function(){

			if( watchCompass === false ) {
				watchCompass = navigator.compass.watchHeading(compassSuccess, compassError, { 'frequency': 20 /*, 'filter':50 */ } );
			}

		});
        //touchstart cause delay clearing the intervall 
		$('#StopHeading , #compassClose').on('touchstart',function(){

			if( watchCompass !== false ) {
				navigator.compass.clearWatch(watchCompass);
				watchCompass = false;
			}

		});

        //dom manipulation 
		$('#StopHeading , #compassClose').on('touchend',function(){

			$('#NeedleTrue , #NeedleMagnetic').removeAttr('style')
			$('#compassAccuracy , #compassStamp').html('...');

		});
	  
	});

}