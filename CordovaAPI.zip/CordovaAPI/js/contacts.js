document.addEventListener("deviceready", contactsAPI, false);

var GlobalContact;

function contactsAPI() {

    $(function(){

    	function contactSuccess(ContactData) {

    		GlobalContact = ContactData;

    		console.log( JSON.stringify(ContactData, null, 4) );

    		$('#ContactOutput')
    		.html( 'Logged to console...<br/>'+ JSON.stringify(ContactData, null, '<br/>') );

    	}

        //0:error unknwon,1: didn't pass the right parameters,2:operation timeout,3:operation pending,4:io error,
        //5:contact api not supported by os, 20: permisson denied by user/os
    	function contactError(errorOBJ) {

    		$('#ContactOutput').html('Error: '+errorOBJ.code);

    		/*
				0:  ContactError.UNKNOWN_ERROR
				1:  ContactError.INVALID_ARGUMENT_ERROR
				2:  ContactError.TIMEOUT_ERROR
				3:  ContactError.PENDING_OPERATION_ERROR
				4:  ContactError.IO_ERROR
				5:  ContactError.NOT_SUPPORTED_ERROR
				20: ContactError.PERMISSION_DENIED_ERROR
    		*/

    	}

    	$('#PickContact').on('touchend',function(){

    		navigator.contacts.pickContact( contactSuccess, contactError );
    		
    	});

    	$('#FindContact').on('touchend',function(){

    		var options = {
    			'filter': "K", // not cas sensetive, multiple results // searching contacts with ks
    			'multiple': true,
    			desiredFields: [ navigator.contacts.fieldType.displayName, //returns only desired fields
    							   navigator.contacts.fieldType.name]
    		}
			
			var searchFields = [
				navigator.contacts.fieldType.displayName,
				navigator.contacts.fieldType.name
			];

			navigator.contacts.find( searchFields, contactSuccess, contactError, options );

    	});

    	$('#CreateContact').on('touchend',function(){

    		GlobalContact = navigator.contacts.create(

	    		{
				    "displayName": "Max Mustermann",
				    "name": {
				        "formatted": "Max Mustermann",
				        "givenName": "Max",
				        "middleName": "Theodor",
				        "familyName": "Mustermann",
				        "honorificPrefix": "Mr",
				        "honorificSuffix": "MD"
				    },
				    "nickname": "Max",
				    "phoneNumbers": [
				        {
				            "type": "mobile",
				            "value": "424242424",
				            "id": 0
				        },
				        {
				            "type": "other",
				            "value": "4242424242",
				            "id": 1
				        }
				    ],
				    "emails": [
				        {
				            "type": "work",
				            "value": "maxmustermann@gmx.com",
				            "id": 0
				        },
				        {
				            "type": "home",
				            "value": "www.9gag.com",
				            "id": 1
				        }
				    ],
				    "addresses": [
				        {
				            "postalCode": "11111",
				            "type": "work",
				            "id": 0,
				            "locality": "Musterstadt",
				            "streetAddress": "42 Musterstraße",
				            "region": "CA",
				            "country": "USA"
				        }
				    ],
				    "ims": [
				        {
				            "id": 0,
				            "value": "Maxi",
				            "type": "other"
				        },
				        {
				            "id": 1,
				            "value": "Goog Max",
				            "type": "other"
				        }
				    ],
				    "organizations": [
				        {
				            "name": "Elumion",
				            "title": "Producer",
				            "type": "CEO",
				            "department": "EWD"
				        }
				    ],
				    "birthday": new Date(254145600000),
				    "note": "This is some notes about Max!!",
				    "urls": [
				        {
				            "type": "profile",
				            "value": "http://www.google.com/"
				        },
				        {
				            "type": "home",
				            "value": "http://www.9gag.com/"
				        }
				    ]
				}

			);

			$('#ContactOutput').html('New contact object in variable GlobalContact has been created.');

    	});

		$('#SaveContact').on('touchend',function(){

			GlobalContact.save(

				function(){ $('#ContactOutput').html('Contact saved.'); },

				contactError
			);

		});

		$('#RemoveContact').on('touchend',function(){

			GlobalContact.remove( //needs id to be removed
				
				function(){ $('#ContactOutput').html('Contact removed.'); },
				
				contactError
			);

		});

		$('#CloneContact').on('touchend',function(){

			var clonedContact = GlobalContact.clone();

			$('#ContactOutput').html('Cloned contact: '+ clonedContact.name.formatted );

		});

    });

}