document.addEventListener("deviceready", dialogsAPI, false);

function dialogsAPI() {

	$(function(){

		function DialogReturned(msg) {
			$('#DialogReturn').html(msg);
		}

		$('#OpenDialog').on('touchend',function(){
			navigator.notification.alert(
				'You are the winner!',  			 // message
			    DialogReturned('Yup all\'s working'),// callback
			    'Game Over',            			 // title (optional)
			    'Done'                  			 // buttonName (optional)
			);
		});

		$('#OpenConfirmDialog').on('touchend',function(){
			navigator.notification.confirm(
				'Do you like mash spud?',   // message
			    DialogReturned,			   // callback
			    'Mash Spud?',              // title (optional)
			    ['LOVE!','Maybe','NO!']   // buttonName (optional)
			);
		});

		function DialogPromptReturned(msg) {
			$('#DialogReturn').html('Button Index: '+msg.buttonIndex+'<br/>Input: '+ msg.input1 );
		}

		$('#OpenPromptDialog').on('touchend',function(){
            
			navigator.notification.prompt(
				'What\'s your sport?',    // message
			    DialogPromptReturned,	  // callback
			    'Sport',                  // title (optional)
			    ['Yup','Yes','No'],  // buttonName (optional)
			    'Tennis'         // Default text (optional)
			);
            
		});

		$('#OpenBeepDialog').on('touchend',function(){
			navigator.notification.alert(
				'You are the winner!',  			 			// message
			    DialogReturned('Yup that\'s beeping fantastic!')// callback
			);
			navigator.notification.beep(2); // how many times to play
		});

	});

}