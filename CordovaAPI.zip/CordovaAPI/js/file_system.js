document.addEventListener("deviceready", fileSystemAPI, false);

function fileSystemAPI() {

    $(function(){

    // Internal App Directories - www, cache directory, when app installed it have its own internal storage

        //where application is stored/unpacked -> only read
        $('#appDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.applicationDirectory );
        });

        //sandbox-> only your app can access this storage 
        $('#appStorageDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.applicationStorageDirectory );
        });

        //persistent private storage/sandbox subdirectory -> files that u want to keep/only our app can read/not synch to cloud service, secrest directory
        $('#appDataDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.dataDirectory );
        });

        //files are stored until app is quit
        $('#appCacheDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.cacheDirectory );
        });

    // External App Directories SD Card-> recommended for large files -> apple doesn't allow sd cards in their devices 

        //contains persistent files
        $('#appExternalStoreDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.externalApplicationStorageDirectory );
        });

        //put app specific files e.g. setting file
        $('#appExternalDataDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.externalDataDirectory );
        });

        //contains temporary files
        $('#appExternalCacheDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.externalCacheDirectory );
        });

        //points to sd card directory. 
        $('#appExternalRootDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.externalRootDirectory );
        });

    // Other Directories

        //cache has little longer lifecycle -  not synch to icloud
        $('#tempDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.tempDirectory );
        });

        //persistent files -> synch to icloud
        $('#syncDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.syncedDataDirectory );
        });

        //private to our app but important to other apps
        $('#docsDir').on('touchend',function(){
            $('#FileSystemOutput').html( cordova.file.documentsDirectory );
        });

    var logFile;

        function fileError(error) {

            /*  
                1   NOT FOUND ERROR 
                    (eg. File or directory cannot be located)

                2   SECURITY ERROR 
                    (eg. unsafe for Web application, Too many calls on resource or an unspecified security error)

                3   ABORT ERROR 
                    (eg. The user or device cancels the operation)

                4   NOT READABLE ERROR 
                    (eg. The file or directory is protected or another app is currently using the file or directory)

                5   ENCODING ERROR
                    (eg. Make sure that the URL is complete and valid)

                6   NO MODIFICATION ALLOWED ERROR 
                    (eg. Trying to write to a read only directory or file)

                7   INVALID STATE ERROR
                    (eg. The operation cannot be performed on the current state of the interface object)

                8   SYNTAX ERROR

                9   INVALID MODIFICATION ERROR 
                    (eg. Moving a directory into its own child or moving a file into its parent directory without changing its name)

                10  QUOTA EXCEEDED ERROR
                    (eg. Going over the specified size or no more device storage available)

                11  TYPE MISMATCH ERROR
                    (eg. The app is accessing a DirectoryEntry when the user is requesting a FileEntry)

                12  PATH EXISTS ERROR
                    (eg. if exclusive is true it found directory or file and threw this error)  */

            $('#FileSystemOutput').html('Error: ' + error.code);

        }

        function fileSuccess(fs) {

            console.log(fs);
            //which directory we want to target
            fs.root.getDirectory( 

                'myNewDirectory' , 
                //true:create directory, exclusive: true->dir or file is found it throw an error-doesn't exist yet, false->don't check exclusivity 
                {create: true, exclusive: false}, 

                function(directoryEntry){

                    document.getElementById('FileSystemOutput').innerHTML =  
                        'Directory "Documents" found or created <br/>'+
                        'isFile: '+ directoryEntry.isFile +'<br/>'+
                        'isDirectory: '+ directoryEntry.isDirectory +'<br/>'+
                        'Directory Name: '+ directoryEntry.name +'<br/>'+
                        'Directory Path: '+ directoryEntry.fullPath +'<br/>'+
                        'Native Path: '+ directoryEntry.nativeURL +'<br/>';

                    /*  directoryEntry Methods

                        directoryEntry.getDirectory()  : Create or look up a directory.

                        directoryEntry.getFile()       : Create or look up a file.

                        directoryEntry.getMetadata()   : Look up metadata about a directory.

                        directoryEntry.setMetadata()   : Set metadata on a directory.

                        directoryEntry.moveTo()        : Move a directory to a different location on the file system.

                        directoryEntry.copyTo()        : Copy a directory to a different location on the file system.

                        directoryEntry.toURL()         : Return a URL to help locate a directory.

                        directoryEntry.getParent()     : Look up the parent directory.

                        directoryEntry.createReader()  : Create a new DirectoryReader that can read entries from a directory.

                        directoryEntry.remove()        : Delete a directory. The directory must be empty.

                        directoryEntry.removeRecursively() : Delete a directory and all of its contents.

                    */

                    directoryEntry.getFile(

                        'logFile.txt', 

                        {create: true, exclusive: false}, 

                        function(fileEntry){

                            document.getElementById('FileSystemOutput').innerHTML +=  
                                '<br/><br/> File "logFile.txt" found or created <br/>'+
                                'isFile: '+ fileEntry.isFile +'<br/>'+
                                'isDirectory: '+ fileEntry.isDirectory +'<br/>'+
                                'File Name: '+ fileEntry.name +'<br/>'+
                                'File Path: '+ fileEntry.fullPath +'<br/>'+
                                'Native Path: '+ fileEntry.nativeURL +'<br/>';

                            logFile = fileEntry;

                            /*  getMetadata()   : Look up metadata about a file.

                                setMetadata()   : Set metadata on a file.

                                moveTo()        : Move a file to a different location on the file system.

                                copyTo()        : Copy a file to a different location on the file system.

                                toURL()         : Return a URL that can be used to locate a file.

                                remove()        : Delete a file.

                                getParent()     : Look up the parent directory.

                                createWriter()  : Creates a FileWriter object that can be used to write to a file.

                                file()          : Creates a File object containing file properties and reader for grabbing the files content.
                            */

                        }, 

                        fileError

                    );

                }, 

                fileError
            );

        }

    // Get Temporary Storage

        $('#fileTemp').on('touchend',function(){

            requestFileSystem( TEMPORARY, 5*1024*1024 /*5MB*/, fileSuccess, fileError );

        });

    // OR Get Persistant Storage

        $('#filePersistent').on('touchend',function(){

            requestFileSystem( PERSISTENT, 5*1024*1024 /*5MB*/, fileSuccess, fileError );

        });

    // Wirte content to logFile.txt

        function writeSuccess(writer){

            writer.write("This text has been inputted from the write method...");

            $('#FileSystemOutput').html('File has been written to, ready to read.');

        }

        $('#writeToFile').on('touchend',function(){

            logFile.createWriter( writeSuccess, fileError );

        });

    // Read logFile content's

        $('#readFile').on('touchend',function(){

            logFile.file( function(file) {

                    console.log(file);

                    var reader = new FileReader();

                    /*  Reader Methods

                        abort(): Aborts reading file.

                        readAsDataURL(file): Read file and return data as a base64-encoded data URL.

                        readAsText(file): Reads text file.

                        readAsBinaryString(file): Reads file as binary and returns a binary string.

                        readAsArrayBuffer(file): Reads file as an ArrayBuffer.

                    */

                    reader.readAsText(file);

                    /*  Reader properties

                        readyState: One of the reader's three possible states, either EMPTY, LOADING or DONE.

                        error: An object containing errors. (FileError)

                        onerror: Called when the read has failed. (Function)

                        onloadstart: Called when the read starts. (Function)

                        onload: Called when the read operation has successfully completed. (Function)

                        onabort: Called when the read operation has been aborted. For instance, by invoking the abort() method. (Function)

                        onloadend: Called when the request has completed (either in success or failure). (Function)

                        result: The contents of the file that have been read. (DOMString)

                    */

                    reader.onload = function (ProgressEvent) {

                        console.log( ProgressEvent, ProgressEvent.target.result );

                        $('#FileSystemOutput').html( reader.result );

                    }

                    reader.onerror = function () {

                        alert( reader.error );

                    }


                },

                fileError

            );

        });

    });

}