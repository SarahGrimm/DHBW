document.addEventListener("deviceready", geoAPI, false);

function geoAPI() {

    $(function(){

      function geoSuccess(position) {

        $('#geoLatitude').html(         position.coords.latitude          );
        $('#geoLongitude').html(        position.coords.longitude         );
        $('#geoAccuracy').html(         position.coords.accuracy          );
        $('#geoAltitude').html(         position.coords.altitude          );
        $('#geoAltitudeAccuracy').html( position.coords.altitudeAccuracy  );
        $('#geoHeading').html(          position.coords.heading           );
        $('#geoSpeed').html(            position.coords.speed             );
        $('#geoTimestamp').html(      new Date( position.timestamp )      );

      }

      //1: user denied our app access to gps, 2: unable to get satellite or network, 3: couldn't fetch data within in timeout
      function geoError(error) {
        alert('code: '    + error.code    + '\n' +
              'message: ' + error.message);
      }

        // it takes time for information to send and receive. Updates are not frequent 
        //enableHighAccuracy: false: network based method-> not accurate, true:satellite signals
        //maximumAge: accepted cache position. Created less than 5sec ago the previously data will be retrieved 
        //timeout: will define threshold for the data to be received. Invoke error callback function
        var options = { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 };

      $('#GetGeo').on('touchend',function(){
        //geoError and options are optional, limit and control how information is received by gps-sensor
        navigator.geolocation.getCurrentPosition( geoSuccess, geoError, options );

      });

      var geoWatchID = false;

      $('#GeoWatch').on('touchend',function(){
          
        if( geoWatchID === false ) {
          geoWatchID = navigator.geolocation.watchPosition( geoSuccess, geoError, options );
        }

      });

      $('#GeoStop, #GeoClose').on('touchend',function(){

        if( geoWatchID !== false ) {
          navigator.geolocation.clearWatch( geoWatchID );
          geoWatchID = false;
        }

        $('#geoReturn span').html('...');

      });

  });

}
