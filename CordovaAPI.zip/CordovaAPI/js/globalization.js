document.addEventListener("deviceready", globalizationAPI, false);

function globalizationAPI() {

    $(function(){

      function globeSuccess(returnedOBJ){

        var keyArray = Object.keys(returnedOBJ), i = 0;

        $('#GlobeOBJ').html('');

        for( i; i < keyArray.length; i++ ) {
          $('#GlobeOBJ').append( keyArray[i] + ' : ' + returnedOBJ[ keyArray[i] ] + ',<br/>' );
        }

      }

      function globeError(errorOBJ){ alert( errorOBJ.code +'\n'+ errorOBJ.message ); }

      var globe = navigator.globalization;

      $('#getPreferredLanguage').on('touchend', function(){

          globe.getPreferredLanguage( 

            globeSuccess, 

            globeError 

          );

      });

      $('#getLocaleName').on('touchend', function(){
          
          globe.getLocaleName( 

            globeSuccess, 

            globeError 

          );

      });

      $('#dateToString').on('touchend', function(){
          
          //new Date
          globe.dateToString(

            new Date, 

            globeSuccess, 

            globeError, 

            { 'formatLength': 'short', 'selector': 'date and time' } 
            // formatLength can be short, medium, long, or full
            // selector can be date, time or date and time.

          );

      });

      $('#stringToDate').on('touchend', function(){
          
          globe.stringToDate( 

            '24.4.2016',

            globeSuccess,

            globeError,

            { 'formatLength':'short', 'selector':'date' }
            // formatLength can be short, medium, long, or full
            // selector can be date, time or date and time

          );

      });

      $('#getDatePattern').on('touchend', function(){
          
          globe.getDatePattern(

            globeSuccess,

            globeError,

            { formatLength: 'short', selector: 'date and time' }
            // formatLength can be short, medium, long, or full
            // selector can be date, time or date and time

          );

      });

      $('#getDateNames').on('touchend', function(){
          
          globe.getDateNames(

            globeSuccess,

            globeError,

            {  item: 'months', type: 'wide' }
            // item can be months or days
            // type can be narrow or wide

          );

      });

      $('#isDayLightSavingsTime').on('touchend', function(){
          
          globe.isDayLightSavingsTime( 

            new Date,

            globeSuccess,

            globeError

          );
      });

      $('#getFirstDayOfWeek').on('touchend', function(){
          
          globe.getFirstDayOfWeek( 

            globeSuccess, 

            globeError 

          );

      });

      $('#numberToString').on('touchend', function(){
          
          globe.numberToString( 

            3.1415926, 

            globeSuccess, 

            globeError, 

            {type:'currency'}
            // type can be 'decimal', 'percent', or 'currency'

          );

      });

      $('#stringToNumber').on('touchend', function(){
          
          globe.stringToNumber( 

            '$150.20', 

            globeSuccess, 

            globeError, 

            {type:'currency'} 
            // type can be decimal, percent, or currency

          );

      });

      $('#getNumberPattern').on('touchend', function(){
         
          globe.getNumberPattern( 

              globeSuccess,

              globeError,

              {type:'currency'} 
              // type can be decimal, percent, or currency

          );

      });

      $('#getCurrencyPattern').on('touchend', function(){
          
          globe.getCurrencyPattern( 

            'USD', 

            globeSuccess, 

            globeError 

          );
          
      });

  });

}
