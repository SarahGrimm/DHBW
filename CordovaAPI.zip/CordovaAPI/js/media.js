document.addEventListener("deviceready", mediaAPI, false);


function getPhoneGapPath() {

    var path = window.location.pathname;
    console.log(path);
    path = path.substr( path, path.length - 10 ); //strip off index.html
    console.log(path);
    return 'file://' + path;

};


function mediaAPI() {

    $(function(){

		// Create simple media...

        var sourceToPlay;
        
        //differnt values for different os
        if( device.platform === 'Android' ) {
            sourceToPlay = getPhoneGapPath() + 'Warriors.mp3';
        } else {
            sourceToPlay = 'Warriors.mp3';
        }

        function mediaStatus(status){

            $('#Duration').html(  Math.floor( media.getDuration() ) );
            
            if(status === 0){
                $('#MediaOutput').html('Sorry no media!');
            }
            
            if(status === 1){
                $('#MediaOutput').html('Loading...');
            }
            
            if(status === 2){
                $('#MediaOutput').html('Playing...');
            }
            
            if(status === 3){
                $('#MediaOutput').html('Paused...');
            }
            
            if(status === 4){
                $('#MediaOutput').html('Stopped!');
            }
  
        }

        //1: App was closed/aborted, 2: Media error network, 3: unable to decode, 4:media not supported 
        function mediaError(errorOBJ){
            $('#MediaOutput').html('There was a problem. Error code '+ errorOBJ.code );
        }

        // no success-callback function, cause no parameters are passed to the function
        var media = new Media( sourceToPlay, null, mediaError, mediaStatus );

        // Playback Controls...

    	$('#mediaPlay').on('touchend',function(){
    		media.play();
    	});

    	$('#mediaPause').on('touchend',function(){
    		media.pause();
    	});

        $('#mediaStop').on('touchend',function(){
            media.stop();
        });

        //volume of specific file -> doesn't change the volume at all. 0-1
        $('#mediaVolume').on('touchend',function(){
            media.setVolume(0.1);
        });

        $('#mediaPosition').on('touchend',function(){

            media.getCurrentPosition(

                function(position){

                    if( position > 0 ) {

                        $('#MediaPos').html(position+'sec'); 

                    } else {

                        $('#MediaPos').html('Not Playing'); 

                    }

                },
               
                function (e) {

                     $('#MediaPos').html("Error getting position " + e);

                }

            );

        });

        $('#mediaSeek').on('touchend',function(){
            media.seekTo(2500);
        });

        //free memory 
        $('#MediaClose, #mediaRelease').on('touchend',function(){
            media.release();
        });

	});
    
}