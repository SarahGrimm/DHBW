document.addEventListener("deviceready", captureAPI, false);

function captureAPI() {

    $(function(){
        
        //Array
        function captureSuccess(mediaFiles) {

            console.log( mediaFiles );

            $('#CaptureOutput').html( JSON.stringify( mediaFiles, null, '<br/>' ) );

            var i;

            for (i = 0; i < mediaFiles.length; i++ ) {

                var mediaFile = mediaFiles[i];

                mediaFile.getFormatData(

                    function(data){ 

                        $('#CaptureOutput').append( '<hr/>'+ JSON.stringify( data, null, '<br/>' ) );

                    },

                    function(err){ alert( err.code ); }

                );
                
            }
        }

        function captureError(error){

            navigator.notification.alert('Error code: '+ error.code);

        }

        
        var capture = navigator.device.capture;
        
        //limit amount of media which will captured, on IOS it's ignored, limit duration ->duration option is ignored on android
        var captureOptions = { limit: 3, duration: 10 };

		$('#captureAudio').on('touchend',function(){
            
            console.log("hhhhhh");
            capture.captureAudio( captureSuccess, captureError,  captureOptions );

        });
        
        $('#captureImage').on('touchend',function(){

             capture.captureImage( captureSuccess, captureError,  captureOptions );

        });

        $('#captureVideo').on('touchend',function(){

             capture.captureVideo( captureSuccess, captureError,  captureOptions );

        });

	});

}