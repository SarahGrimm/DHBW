document.addEventListener("deviceready", statusbarAPI, false);

function statusbarAPI() {

    $(function () {


        $("#phone-number").on('touchend', function () {
            var phoneLink = $(this).attr("href");
            console.log(phoneLink);
            window.open(phoneLink, "_system", "location=yes");
        });

        $("#geo").on('touchend', function () {
            var phoneLink = $(this).attr("href");
            console.log(phoneLink);
            window.open(phoneLink, "_system", "location=yes");
        });

        $("#sms").on('touchend', function () {
            var phoneLink = $(this).attr("href");
            console.log(phoneLink);
            window.open(phoneLink, "_system", "location=yes");
        });

        $("#mail").on('touchend', function () {
            var phoneLink = $(this).attr("href");
            console.log(phoneLink);
            window.open(phoneLink, "_system", "location=yes");
        });



    });

}