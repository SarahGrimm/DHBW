/**
 * 
 * Provides QR Scanner functionality. BarcodeScanner plugin is needed. => phonegap plugin add phonegap-plugin-barcodescanner
 * 
* @author  Sarah Richter
* @version 1.0
* @since   2017-12-01 
*/

App.scanner = (function () {

    function qrscan() {
       //TODO
    }

    return {
        qrscan: qrscan
    }



})();