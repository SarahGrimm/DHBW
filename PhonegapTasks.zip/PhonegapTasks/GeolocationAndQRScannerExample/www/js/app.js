/**
 * App namespace
 * 
* @author  Sarah Richter
* @version 1.0
* @since   2017-12-01 
*/

var App = App || {};