/**
 * 
 * Initializes map and calculates distance to next station. Cordova Geolocation plugin is needed. => cordova plugin add cordova-plugin-geolocation
 * 
* @author  Sarah Richter
* @version 1.0
* @since   2017-12-01 
*/


App.map = (function () {

  var map = null;

  function initialize() {
    $(document).ready(function () {

      var heightScreen = $(document).height();
      var mapTop = $('#map').position().top;
      var heightMap = heightScreen - mapTop;
      $('#map').outerHeight(heightMap);

      map = L.map('map').setView([51.505, -0.09], 13);

      L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);

      //Locate Plugin
      map.addControl(L.control.locate({
        locateOptions: {
          maxZoom: 10
        }
      }));

      SetMarkerStation();
      App.interval = setInterval(calculate, 100);
      App.nextStation = false;
    });
  }

  function SetMarkerStation() {
    var station = App.ralley.getRalley();
    console.log(station);
    var korlat = station.lat;
    var korlng = station.lng;

    var marker = L.marker([korlat, korlng]).addTo(map);
    marker.bindPopup("<b>" + station.name + "</b><br>" + marker.getLatLng()).openPopup();

  }

  
  function calculate() {

  //TODO
  }

  return {
    initialize: initialize
  }

})();