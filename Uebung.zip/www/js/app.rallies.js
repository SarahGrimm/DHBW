(function(){


    let rallies = [{ "id": "0", "name": "Ralley1", "lat": "49.13051", "lng": "9.26147" },
    { "id": "1", "name": "Ralley2", "lat": "49.13051", "lng": "9.26147" }]




})();