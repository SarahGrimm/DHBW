/**
 * 
 * Manages active Ralley. 
 * 
* @author  Sarah Richter
* @version 1.0
* @since   2017-12-01 
*/

App.ralley = (function () {

    var activeRalley = null;
    function setRalley(ralley) {
        console.log(ralley);
        activeRalley = ralley;
    }

    function getRalley() {
        return activeRalley;
    }

    return {
        setRalley: setRalley,
        getRalley: getRalley

    }

})();
