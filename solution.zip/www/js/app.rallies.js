/**
 * 
 * Displays available rallies from dummy data. 
 * 
* @author  Sarah Richter
* @version 1.0
* @since   2017-12-01 
*/

(function () {

    var rallies = [{ "id": "0", "name": "Ralley1", "lat": "49.13051", "lng": "9.26147" },
    { "id": "1", "name": "Ralley2", "lat": "49.13051", "lng": "9.26147" }]


    App.util.load("#mainContainer", "sites/rallies.html", function () {

        var h = [];

        for (let i = 0; i < rallies.length; i++) {
            h.push('<li class="list-group-item list-group-item-success" data-ralley-id =" ');
            h.push(rallies[i].id);
            h.push('">');
            h.push(rallies[i].name);
            h.push("</li>");
        }

        $("#rallies").html(h.join(''));

        $("#rallies").on("click", " > li", function () {
            var index = parseInt($(this).attr("data-ralley-id"));
            console.log(index);
            App.ralley.setRalley(rallies[index]);
            console.log(App.ralley.getRalley());

            App.util.load("#mainContainer", "sites/map.html", function () {
                App.map.initialize();
            });

        });
    });

})();