import { Component } from '@angular/core';
import { Summary } from '@angular/compiler';
import { TestService } from '../services/test.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  nums: number[];
  name2 = "Franz";


  constructor(testService: TestService) {
    this.nums = testService.getList();

  }

}
