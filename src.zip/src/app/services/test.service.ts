import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor() { }

  list: number[] = [1, 2, 3];

  getList() {
    return this.list;
  }

}
