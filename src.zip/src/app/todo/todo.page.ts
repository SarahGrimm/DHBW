import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { switchMap, map, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import { DbService } from '../services/db.service';
import { TodoFormComponent } from './todo-form/todo-form.component';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.page.html',
  styleUrls: ['./todo.page.scss'],
})
export class TodoPage implements OnInit {

  filter = new BehaviorSubject(null);

  constructor() { }

  ngOnInit() {
  }
}
