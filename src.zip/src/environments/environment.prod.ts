export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyCgLlgTF0bZfQQfg_qQgCtBFR65uLFV0J4',
    authDomain: 'ionfire-8d3dd.firebaseapp.com',
    databaseURL: 'https://ionfire-8d3dd.firebaseio.com',
    projectId: 'ionfire-8d3dd',
    storageBucket: 'ionfire-8d3dd.appspot.com',
    messagingSenderId: '140960893859'
  }
};
