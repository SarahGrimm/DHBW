App.map = (function(){

  var map = null;

  function initialize() {
    $(document).ready(function(){

      var heightScreen = $(document).height();
      var mapTop = $('#map').position().top;
      var heightMap = heightScreen - mapTop;
      $('#map').outerHeight(heightMap);

      map = L.map('map').setView([51.505, -0.09], 13);

      L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);

      //Locate Plugin
      map.addControl(L.control.locate({
       locateOptions: {
               maxZoom: 10
      }}));
    });
  }

 
  return {
    initialize: initialize
  }

})();