(function(){


    let rallies = [{ "id": "0", "name": "Ralley1", "lat": "49.13051", "lng": "9.26147" },
    { "id": "1", "name": "Ralley2", "lat": "49.13051", "lng": "9.26147" }]


    App.util.load("#main-container", "/sites/rallies.html", function(){


        let h =  [];
        rallies.map((rallies)=> {
            h.push('<li class="list-group-item" data-ralley-id="');
            h.push(rallies.id);
            h.push('">');
            h.push(rallies.name);
            h.push("</li>");

        });

        $("#rallies").html(h.join(""));

        $("#rallies").on("click", " > li", function(){
            var index = parseInt($(this).attr("data-ralley-id"));
            App.ralley.setRalley(rallies[index]);

            App.util.load("#main-container", "sites/map.html", function () {
                App.map.initialize();
            });



        })



    });






})();